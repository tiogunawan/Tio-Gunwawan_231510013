import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/library_provider.dart';
import 'screens/auth/login_page.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => LibraryProvider(),
      child: MaterialApp(
        title: 'M-Library',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: const Color(0xFFB22222),
          colorScheme: ColorScheme.fromSwatch().copyWith(
            secondary: const Color(0xFFD4AF37),
          ),
        ),
        home: LoginPage(),
      ),
    ),
  );
}
