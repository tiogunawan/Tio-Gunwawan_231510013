class UserModel {
  final String email;
  final String password;
  final String role;
  final String fullName;

  UserModel({
    required this.email,
    required this.password,
    required this.role,
    required this.fullName,
  });
}

class BookModel {
  final String id;
  final String title;
  final String author;
  String status;
  String? borrowedBy;
  DateTime? dueDate;
  DateTime? returnDate;
  double fine;

  BookModel({
    required this.id,
    required this.title,
    required this.author,
    this.status = 'Available',
    this.borrowedBy,
    this.dueDate,
    this.returnDate,
    this.fine = 0.0,
  });
}
