class BookModel {
  final String id;
  final String title;
  final String author;
  String status; // 'Available', 'Pending', 'Borrowed'
  String? borrowedBy;

  BookModel({
    required this.id,
    required this.title,
    required this.author,
    this.status = 'Available',
    this.borrowedBy,
  });
}
