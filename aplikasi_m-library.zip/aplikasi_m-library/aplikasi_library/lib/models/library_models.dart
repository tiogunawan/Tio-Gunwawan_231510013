class UserModel {
  final String email;
  final String password;
  final String role;
  final String fullName;

  UserModel({
    required this.email,
    required this.password,
    required this.role,
    required this.fullName,
  });
}

class BookModel {
  final String id;
  final String title;
  final String author;
  final String category;
  String status;
  String? borrowedBy;
  DateTime? dueDate;
  DateTime? returnDate;
  double fine;
  int borrowCount;

  BookModel({
    required this.id,
    required this.title,
    required this.author,
    required this.category,
    this.status = 'Available',
    this.borrowedBy,
    this.dueDate,
    this.returnDate,
    this.fine = 0.0,
    this.borrowCount = 0,
  });
}
