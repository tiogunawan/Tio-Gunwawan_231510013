import 'package:flutter/material.dart';
import '../models/library_models.dart';

class LibraryProvider with ChangeNotifier {
  // 1. DATA PENGGUNA (Tetap sesuai kode kamu)
  List<UserModel> _users = [
    UserModel(
      email: "manager@mail.com",
      password: "123",
      role: "Manager",
      fullName: "Budi Manager",
    ),
    UserModel(
      email: "librarian@mail.com",
      password: "123",
      role: "Librarian",
      fullName: "Siti Pustakawan",
    ),
    UserModel(
      email: "member@mail.com",
      password: "123",
      role: "Member",
      fullName: "Andi Member",
    ),
  ];

  // 2. DATA KOLEKSI BUKU (Tetap sesuai kode kamu)
  List<BookModel> _books = [
    BookModel(
      id: "1",
      title: "Pemrograman Flutter",
      author: "Google Team",
      category: "Pelajaran",
    ),
    BookModel(
      id: "2",
      title: "Belajar Dart Dasar",
      author: "Dart Org",
      category: "Pelajaran",
    ),
    BookModel(
      id: "10",
      title: "Matematika Diskrit",
      author: "Rinaldi Munir",
      category: "Pelajaran",
    ),
    BookModel(
      id: "3",
      title: "Laskar Pelangi",
      author: "Andrea Hirata",
      category: "Novel",
    ),
    BookModel(id: "4", title: "Bumi", author: "Tere Liye", category: "Novel"),
    BookModel(
      id: "5",
      title: "Negeri 5 Menara",
      author: "A. Fuadi",
      category: "Novel",
    ),
    BookModel(
      id: "6",
      title: "Artificial Intelligence",
      author: "Yann LeCun",
      category: "Teknologi",
    ),
    BookModel(
      id: "7",
      title: "Cyber Security 101",
      author: "Kevin Mitnick",
      category: "Teknologi",
    ),
    BookModel(
      id: "8",
      title: "Sejarah Dunia",
      author: "HG Wells",
      category: "Sejarah",
    ),
    BookModel(
      id: "9",
      title: "Biografi BJ Habibie",
      author: "A. Makmur Makka",
      category: "Sejarah",
    ),
  ];

  List<BookModel> _history = [];
  UserModel? _currentUser;
  List<String> _notifications = [];

  // --- GETTERS ---
  UserModel? get currentUser => _currentUser;
  List<BookModel> get books => _books;
  List<BookModel> get history => _history;
  List<UserModel> get allUsers => _users;
  List<String> get notifications => _notifications;
  int get borrowedCount => _books.where((b) => b.status == 'Borrowed').length;

  // --- AUTHENTICATION ---
  void register(UserModel user) {
    _users.add(user);
    notifyListeners();
  }

  bool login(String email, String password, String role) {
    try {
      _currentUser = _users.firstWhere(
        (u) => u.email == email && u.password == password && u.role == role,
      );
      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }

  // --- MANAJEMEN BUKU ---
  void addBook(String title, String author, String category) {
    _books.add(
      BookModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: title,
        author: author,
        category: category,
      ),
    );
    _notifications.insert(0, "Buku Baru: '$title' tersedia!");
    notifyListeners();
  }

  void deleteBook(String id) {
    _books.removeWhere((b) => b.id == id);
    notifyListeners();
  }

  // --- PEMINJAMAN ---
  void requestBook(String bookId) {
    int i = _books.indexWhere((b) => b.id == bookId);
    if (i != -1) {
      _books[i].status = 'Pending';
      _books[i].borrowedBy = _currentUser?.fullName;
      notifyListeners();
    }
  }

  void grantBook(String bookId) {
    int i = _books.indexWhere((b) => b.id == bookId);
    if (i != -1) {
      _books[i].status = 'Borrowed';
      _books[i].borrowCount++;
      _books[i].dueDate = DateTime.now().add(const Duration(days: 7));
      notifyListeners();
    }
  }

  // --- LOGIKA DENDA & PENGEMBALIAN ---

  double calculateLiveFine(DateTime? dueDate) {
    if (dueDate == null) return 0;
    final now = DateTime.now();
    if (now.isAfter(dueDate)) {
      int daysLate = now.difference(dueDate).inDays;
      if (daysLate <= 0) daysLate = 1;
      return daysLate * 5000.0;
    }
    return 0;
  }

  // Digunakan saat member membayar denda dari Dashboard
  void processReturnWithPayment(String bookId, double finePaid) {
    int i = _books.indexWhere((b) => b.id == bookId);
    if (i != -1) {
      _history.add(
        BookModel(
          id: _books[i].id,
          title: _books[i].title,
          author: _books[i].author,
          category: _books[i].category,
          status: 'Returned',
          borrowedBy: _books[i].borrowedBy,
          fine: 0, // Set 0 karena denda sudah dibayar lunas
          returnDate: DateTime.now(),
        ),
      );

      _books[i].status = 'Available';
      _books[i].borrowedBy = null;
      _books[i].dueDate = null;
      notifyListeners();
    }
  }

  // Membayar satu denda di halaman History (Membatalkan error kamu)
  void payFine(String bookId) {
    int i = _history.indexWhere((b) => b.id == bookId);
    if (i != -1) {
      _history[i].fine = 0;
      notifyListeners();
    }
  }

  // Membayar semua denda di halaman History (Membatalkan error kamu)
  void payAllFines() {
    for (var book in _history) {
      book.fine = 0;
    }
    notifyListeners();
  }

  void returnBook(String bookId) {
    int i = _books.indexWhere((b) => b.id == bookId);
    if (i != -1) {
      _books[i].status = 'Returning';
      notifyListeners();
    }
  }

  void confirmReturn(String bookId) {
    int i = _books.indexWhere((b) => b.id == bookId);
    if (i != -1) {
      double currentFine = calculateLiveFine(_books[i].dueDate);

      _history.add(
        BookModel(
          id: _books[i].id,
          title: _books[i].title,
          author: _books[i].author,
          category: _books[i].category,
          status: 'Returned',
          borrowedBy: _books[i].borrowedBy,
          fine: currentFine,
          returnDate: DateTime.now(),
        ),
      );

      _books[i].status = 'Available';
      _books[i].borrowedBy = null;
      _books[i].dueDate = null;
      notifyListeners();
    }
  }

  // --- FUNGSI TAMBAHAN ---
  double getTotalFines() {
    return _history.fold(0, (sum, book) => sum + book.fine);
  }

  List<BookModel> getTopBooks() {
    List<BookModel> sorted = List.from(_books);
    sorted.sort((a, b) => b.borrowCount.compareTo(a.borrowCount));
    return sorted.where((b) => b.borrowCount > 0).take(3).toList();
  }

  void clearNotifications() {
    _notifications.clear();
    notifyListeners();
  }
}
