import 'package:flutter/material.dart';

class AppColors {
  // Warna sesuai permintaan tema aplikasi
  static const Color primaryRed = Color(0xFFB22222); // Merah
  static const Color secondaryBlue = Color(0xFF0000FF); // Biru
  static const Color accentGold = Color(0xFFD4AF37); // Coklat Keemasan
  static const Color backgroundWhite = Colors.white;
}

class AppTextStyle {
  static const TextStyle headerStyle = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    color: AppColors.primaryRed,
  );

  static const TextStyle subHeaderStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: AppColors.secondaryBlue,
  );
}
