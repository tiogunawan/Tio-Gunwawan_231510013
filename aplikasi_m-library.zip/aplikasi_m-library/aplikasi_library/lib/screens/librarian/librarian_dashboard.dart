import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/library_provider.dart';
import '../../models/library_models.dart';
import '../auth/login_page.dart';

class LibrarianDashboard extends StatefulWidget {
  const LibrarianDashboard({super.key});

  @override
  State<LibrarianDashboard> createState() => _LibrarianDashboardState();
}

class _LibrarianDashboardState extends State<LibrarianDashboard> {
  String _searchQuery = "";
  String _selectedFilter = "Semua";

  @override
  Widget build(BuildContext context) {
    // Mengambil data dari provider
    final prov = Provider.of<LibraryProvider>(context);

    // Logika Filter dan Search
    List<BookModel> displayedBooks = prov.books.where((book) {
      bool matchesSearch =
          book.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          book.author.toLowerCase().contains(_searchQuery.toLowerCase());
      bool matchesFilter =
          _selectedFilter == "Semua" || book.status == _selectedFilter;
      return matchesSearch && matchesFilter;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Librarian Panel"),
        backgroundColor: Colors.green, // Warna hijau khas pustakawan
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (_) => const LoginPage()),
              (r) => false,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Tambahan: Bar Pencarian
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              onChanged: (val) => setState(() => _searchQuery = val),
              decoration: InputDecoration(
                hintText: "Cari judul atau penulis...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),

          // Tambahan: Filter Status (Chips)
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children:
                  [
                    "Semua",
                    "Available",
                    "Pending",
                    "Borrowed",
                    "Returning",
                  ].map((status) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 5),
                      child: ChoiceChip(
                        label: Text(status),
                        selected: _selectedFilter == status,
                        onSelected: (selected) {
                          setState(() => _selectedFilter = status);
                        },
                        selectedColor: Colors.green[200],
                      ),
                    );
                  }).toList(),
            ),
          ),

          const Divider(),

          // List Buku (Menggunakan displayedBooks hasil filter)
          Expanded(
            child: displayedBooks.isEmpty
                ? const Center(child: Text("Buku tidak ditemukan."))
                : ListView.builder(
                    itemCount: displayedBooks.length,
                    itemBuilder: (context, i) {
                      final book = displayedBooks[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        child: ListTile(
                          leading: Icon(
                            Icons.book,
                            color: _getStatusColor(book.status),
                          ),
                          title: Text(
                            book.title,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            "${book.author} | Status: ${book.status}",
                          ),
                          trailing: _buildActionButtons(book, prov),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        child: const Icon(Icons.add),
        onPressed: () => _showAddBookDialog(context, prov),
      ),
    );
  }

  // Tambahan: Warna icon dinamis berdasarkan status
  Color _getStatusColor(String status) {
    switch (status) {
      case 'Pending':
        return Colors.blue;
      case 'Borrowed':
        return Colors.red;
      case 'Returning':
        return Colors.orange;
      default:
        return Colors.green;
    }
  }

  // Tombol aksi berdasarkan status buku (Tetap dari kode aslimu)
  Widget? _buildActionButtons(BookModel book, LibraryProvider prov) {
    if (book.status == 'Pending') {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
        onPressed: () => prov.grantBook(book.id),
        child: const Text("Setujui", style: TextStyle(color: Colors.white)),
      );
    } else if (book.status == 'Returning') {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
        onPressed: () => prov.confirmReturn(book.id),
        child: const Text("Selesai", style: TextStyle(color: Colors.white)),
      );
    }
    return null;
  }

  // Dialog Tambah Buku (Tetap dari kode aslimu)
  void _showAddBookDialog(BuildContext context, LibraryProvider prov) {
    final titleController = TextEditingController();
    final authorController = TextEditingController();
    String selectedCategory = "Pelajaran";

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text("Tambah Buku Baru"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: titleController,
                      decoration: const InputDecoration(
                        labelText: "Judul Buku",
                      ),
                    ),
                    TextField(
                      controller: authorController,
                      decoration: const InputDecoration(labelText: "Penulis"),
                    ),
                    const SizedBox(height: 15),
                    DropdownButton<String>(
                      isExpanded: true,
                      value: selectedCategory,
                      items: ["Pelajaran", "Novel", "Teknologi", "Sejarah"]
                          .map(
                            (cat) =>
                                DropdownMenuItem(value: cat, child: Text(cat)),
                          )
                          .toList(),
                      onChanged: (val) {
                        setState(() => selectedCategory = val!);
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Batal"),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (titleController.text.isNotEmpty &&
                        authorController.text.isNotEmpty) {
                      prov.addBook(
                        titleController.text,
                        authorController.text,
                        selectedCategory,
                      );
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Buku berhasil ditambahkan!"),
                        ),
                      );
                    }
                  },
                  child: const Text("Simpan"),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
