import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/library_provider.dart';
import '../../widgets/book_card.dart';
import '../../widgets/custom_button.dart';
import '../auth/login_page.dart';

class ManagerDashboard extends StatefulWidget {
  const ManagerDashboard({super.key});

  @override
  State<ManagerDashboard> createState() => _ManagerDashboardState();
}

class _ManagerDashboardState extends State<ManagerDashboard> {
  String _userSearchQuery = ""; // Tambahan untuk cari user

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<LibraryProvider>(context);

    int totalBooks = prov.books.length;
    int borrowedBooks = prov.borrowedCount;
    double totalFines = prov.getTotalFines();

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: Colors.grey[100],
        appBar: AppBar(
          title: const Text(
            "Manager Overview",
            style: TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 2,
          iconTheme: const IconThemeData(color: Colors.black87),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout, color: Color(0xFFB22222)),
              onPressed: () => Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              ),
            ),
          ],
          bottom: const TabBar(
            labelColor: Color(0xFF0000FF),
            unselectedLabelColor: Colors.grey,
            indicatorColor: Color(0xFFD4AF37),
            tabs: [
              Tab(icon: Icon(Icons.analytics), text: "Statistik"),
              Tab(icon: Icon(Icons.people), text: "User & Buku"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildStatistikPage(prov, totalBooks, borrowedBooks, totalFines),
            _buildManagementPage(context, prov),
          ],
        ),
      ),
    );
  }

  Widget _buildStatistikPage(
    LibraryProvider prov,
    int total,
    int borrowed,
    double fines,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row untuk Card agar tidak terlalu memakan tempat vertikal
          Row(
            children: [
              Expanded(
                child: _buildStatCardSmall(
                  "Koleksi",
                  total.toString(),
                  Colors.blue,
                  Icons.book,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildStatCardSmall(
                  "Pinjam",
                  borrowed.toString(),
                  Colors.orange,
                  Icons.sync,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _buildStatCard(
            "Total Pendapatan Denda",
            "Rp ${fines.toInt()}",
            Colors.green,
          ),

          const SizedBox(height: 25),
          const Row(
            children: [
              Icon(Icons.stars, color: Color(0xFFD4AF37)),
              SizedBox(width: 8),
              Text(
                "Buku Paling Populer",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 10),

          if (prov.getTopBooks().isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(20.0),
                child: Text("Belum ada data peminjaman."),
              ),
            )
          else
            ...prov
                .getTopBooks()
                .take(5)
                .map(
                  (book) => Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ListTile(
                      leading: const Icon(
                        Icons.bookmark,
                        color: Color(0xFF0000FF),
                      ),
                      title: Text(
                        book.title,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(book.category),
                      trailing: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.blue[50],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          "${book.borrowCount}x",
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                          ),
                        ),
                      ),
                    ),
                  ),
                )
                .toList(),
        ],
      ),
    );
  }

  Widget _buildManagementPage(BuildContext context, LibraryProvider prov) {
    // Filter user berdasarkan search query
    final filteredUsers = prov.allUsers
        .where(
          (u) =>
              u.fullName.toLowerCase().contains(_userSearchQuery.toLowerCase()),
        )
        .toList();

    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 10),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: TextField(
            onChanged: (v) => setState(() => _userSearchQuery = v),
            decoration: InputDecoration(
              hintText: "Cari nama pengguna...",
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.all(15),
          child: Text(
            "Daftar Pengguna",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        ...filteredUsers
            .map(
              (u) => Card(
                margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: u.role == 'Librarian'
                        ? Colors.green
                        : const Color(0xFF0000FF),
                    child: const Icon(Icons.person, color: Colors.white),
                  ),
                  title: Text(
                    u.fullName,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text("${u.role} • ${u.email}"),
                  trailing: const Icon(Icons.chevron_right),
                ),
              ),
            )
            .toList(),

        const Divider(height: 40, thickness: 2),

        const Padding(
          padding: EdgeInsets.all(15),
          child: Text(
            "Manajemen Stok Buku",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        ...prov.books
            .map(
              (b) => Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 5,
                ),
                child: BookCard(
                  book: b,
                  trailingWidget: CustomButton(
                    text: "Hapus",
                    color: const Color(0xFFB22222),
                    onPressed: () =>
                        _confirmDelete(context, prov, b.id, b.title),
                  ),
                ),
              ),
            )
            .toList(),
      ],
    );
  }

  // Card kecil untuk Statistik berdampingan
  Widget _buildStatCardSmall(
    String title,
    String value,
    Color color,
    IconData icon,
  ) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border(bottom: BorderSide(color: color, width: 4)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(height: 5),
            Text(
              value,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              title,
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  // Fungsi Card Stat asli kamu yang dipercantik sedikit
  Widget _buildStatCard(String title, String value, Color color) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        padding: const EdgeInsets.all(20),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border(left: BorderSide(color: color, width: 8)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                color: Colors.grey,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              value,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDelete(
    BuildContext context,
    LibraryProvider prov,
    String id,
    String title,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Hapus Buku?"),
        content: Text(
          "Yakin ingin menghapus '$title' dari sistem? Data ini tidak bisa dikembalikan.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          CustomButton(
            text: "Hapus",
            color: const Color(0xFFB22222),
            onPressed: () {
              prov.deleteBook(id);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}
