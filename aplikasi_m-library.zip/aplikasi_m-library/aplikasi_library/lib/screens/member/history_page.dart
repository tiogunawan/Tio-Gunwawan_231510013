import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/library_provider.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<LibraryProvider>(context);

    // Memastikan hanya mengambil riwayat milik user yang sedang login
    final myHistory = prov.history
        .where((h) => h.borrowedBy == prov.currentUser?.fullName)
        .toList();

    // Menghitung total denda yang belum dibayar
    final double totalDenda = myHistory.fold(0, (sum, item) => sum + item.fine);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Riwayat & Denda"),
        backgroundColor: const Color(0xFF0000FF), // Biru Member
      ),
      body: Column(
        children: [
          // HEADER INFO DENDA (Hanya muncul jika ada denda > 0)
          if (totalDenda > 0)
            Container(
              padding: const EdgeInsets.all(20),
              margin: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.red[50],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.red.shade200),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.warning_amber_rounded,
                    color: Colors.red,
                    size: 40,
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Total Tagihan Denda",
                          style: TextStyle(color: Colors.red, fontSize: 12),
                        ),
                        Text(
                          "Rp ${totalDenda.toInt()}",
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.red,
                          ),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                    ),
                    onPressed: () =>
                        _showPaymentDialog(context, prov, "semua denda"),
                    child: const Text(
                      "BAYAR",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),

          // LIST RIWAYAT
          Expanded(
            child: myHistory.isEmpty
                ? const Center(child: Text("Belum ada riwayat peminjaman."))
                : ListView.builder(
                    itemCount: myHistory.length,
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    itemBuilder: (context, i) {
                      final item = myHistory[i];
                      return Card(
                        elevation: 2,
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: Icon(
                            item.fine > 0
                                ? Icons.error_outline
                                : Icons.check_circle_outline,
                            color: item.fine > 0 ? Colors.red : Colors.green,
                          ),
                          title: Text(
                            item.title,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            "Kembali pada: ${item.returnDate?.day}/${item.returnDate?.month}/${item.returnDate?.year}",
                          ),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                item.fine > 0
                                    ? "Rp ${item.fine.toInt()}"
                                    : "Lunas",
                                style: TextStyle(
                                  color: item.fine > 0
                                      ? Colors.red
                                      : Colors.green,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (item.fine > 0)
                                const Text(
                                  "Ketuk untuk bayar",
                                  style: TextStyle(
                                    fontSize: 9,
                                    color: Colors.grey,
                                  ),
                                ),
                            ],
                          ),
                          onTap: item.fine > 0
                              ? () => _showSinglePaymentDialog(
                                  context,
                                  prov,
                                  item.id,
                                  item.title,
                                  item.fine,
                                )
                              : null,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // Dialog untuk bayar satu buku
  void _showSinglePaymentDialog(
    BuildContext context,
    LibraryProvider prov,
    String id,
    String title,
    double fine,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Bayar Denda"),
        content: Text(
          "Bayar denda untuk buku '$title' sebesar Rp ${fine.toInt()}?",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            onPressed: () {
              prov.payFine(id);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Pembayaran berhasil!")),
              );
            },
            child: const Text("Bayar Sekarang"),
          ),
        ],
      ),
    );
  }

  // Dialog untuk bayar semua
  void _showPaymentDialog(
    BuildContext context,
    LibraryProvider prov,
    String msg,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: Text("Apakah Anda yakin ingin membayar $msg?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            onPressed: () {
              prov.payAllFines();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Semua denda lunas!")),
              );
            },
            child: const Text("Ya, Bayar"),
          ),
        ],
      ),
    );
  }
}
