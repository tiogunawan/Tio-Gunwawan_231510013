import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/library_provider.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<LibraryProvider>(context);
    final user = prov.currentUser;

    // LOGIKA ASLI KAMU: Menghitung total pinjam dari history
    final int totalPinjam = prov.history
        .where((h) => h.borrowedBy == user?.fullName)
        .length;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Profil Saya"),
        backgroundColor: const Color(0xFF0000FF),
        elevation: 0, // Membuat AppBar rata dengan header
      ),
      body: Column(
        children: [
          // Header Profil yang Dipercantik
          Container(
            width: double.infinity,
            padding: const EdgeInsets.only(bottom: 30, top: 10),
            decoration: const BoxDecoration(
              color: Color(0xFF0000FF),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.white,
                  child: Text(
                    user?.fullName != null
                        ? user!.fullName[0].toUpperCase()
                        : "U",
                    style: const TextStyle(
                      fontSize: 40,
                      color: Color(0xFF0000FF),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 15),
                Text(
                  user?.fullName ?? "User",
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  user?.email ?? "",
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // Card Statistik (Menggunakan logika totalPinjam kamu)
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.book, color: Color(0xFF0000FF)),
                    title: const Text("Total Riwayat Peminjaman"),
                    trailing: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0000FF).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        totalPinjam.toString(),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0000FF),
                        ),
                      ),
                    ),
                  ),
                  const Divider(indent: 20, endIndent: 20),
                  // Tambahan: Info Role
                  ListTile(
                    leading: const Icon(
                      Icons.verified_user,
                      color: Colors.green,
                    ),
                    title: const Text("Status Akun"),
                    trailing: Text(
                      user?.role ?? "Member",
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Tombol Keluar / Opsi Lainnya
          const Spacer(),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back),
                label: const Text("Kembali ke Beranda"),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  side: const BorderSide(color: Color(0xFF0000FF)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
