import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/library_provider.dart';
import '../../models/library_models.dart';
import '../auth/login_page.dart';
import 'history_page.dart';
import 'profile_page.dart';
import 'payment_page.dart'; // <--- Tambahkan import ini

class MemberDashboard extends StatefulWidget {
  const MemberDashboard({super.key});
  @override
  State<MemberDashboard> createState() => _MemberDashboardState();
}

class _MemberDashboardState extends State<MemberDashboard>
    with SingleTickerProviderStateMixin {
  String _searchQuery = "";
  late TabController _tabController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _showNotificationDialog(BuildContext context, LibraryProvider prov) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Notifikasi Buku Baru"),
        content: SizedBox(
          width: double.maxFinite,
          child: prov.notifications.isEmpty
              ? const Text("Belum ada buku baru yang ditambahkan.")
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: prov.notifications.length,
                  itemBuilder: (context, i) => ListTile(
                    leading: const Icon(
                      Icons.new_releases,
                      color: Colors.orange,
                    ),
                    title: Text(
                      prov.notifications[i],
                      style: const TextStyle(fontSize: 13),
                    ),
                  ),
                ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              prov.clearNotifications();
              Navigator.pop(context);
            },
            child: const Text("Bersihkan"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Tutup"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<LibraryProvider>(context);

    List<BookModel> getFilteredBooks(String category) {
      return prov.books.where((book) {
        bool matchCategory = category == "Semua" || book.category == category;
        bool matchSearch =
            book.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            book.author.toLowerCase().contains(_searchQuery.toLowerCase());
        return matchCategory && matchSearch;
      }).toList();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "M-Library Dashboard",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF0000FF),
        elevation: 0,
        actions: [
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(
                  Icons.notifications_active,
                  color: Colors.white,
                ),
                onPressed: () => _showNotificationDialog(context, prov),
              ),
              if (prov.notifications.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 14,
                      minHeight: 14,
                    ),
                    child: Text(
                      '${prov.notifications.length}',
                      style: const TextStyle(color: Colors.white, fontSize: 8),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (_) => const LoginPage()),
              (r) => false,
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: const Color(0xFFD4AF37),
          indicatorWeight: 3,
          tabs: const [
            Tab(text: "Semua"),
            Tab(text: "Novel"),
            Tab(text: "Pelajaran"),
            Tab(text: "Teknologi"),
            Tab(text: "Sejarah"),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              onChanged: (v) => setState(() => _searchQuery = v),
              decoration: InputDecoration(
                hintText: "Cari judul buku atau penulis...",
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.grey[100],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildBookList(getFilteredBooks("Semua"), prov),
                _buildBookList(getFilteredBooks("Novel"), prov),
                _buildBookList(getFilteredBooks("Pelajaran"), prov),
                _buildBookList(getFilteredBooks("Teknologi"), prov),
                _buildBookList(getFilteredBooks("Sejarah"), prov),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: const Color(0xFF0000FF),
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() => _currentIndex = index);
          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HistoryPage()),
            );
          } else if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ProfilePage()),
            );
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Beranda"),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: "Riwayat"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profil"),
        ],
      ),
    );
  }

  Widget _buildBookList(List<BookModel> filteredBooks, LibraryProvider prov) {
    if (filteredBooks.isEmpty) {
      return const Center(child: Text("Buku tidak ditemukan."));
    }

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 20),
      itemCount: filteredBooks.length,
      itemBuilder: (context, i) {
        final book = filteredBooks[i];
        bool isMyBook = book.borrowedBy == prov.currentUser?.fullName;
        double liveFine = prov.calculateLiveFine(book.dueDate);

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Hero(
                  tag: book.id,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      "https://picsum.photos/seed/${book.id}/200/300",
                      width: 70,
                      height: 100,
                      fit: BoxFit.cover,
                      errorBuilder: (c, e, s) =>
                          const Icon(Icons.book, size: 70),
                    ),
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        book.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        book.author,
                        style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 8),
                      _buildStatusChip(book.status),
                      if (isMyBook &&
                          book.status == 'Borrowed' &&
                          liveFine > 0) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.red[50],
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.red.shade200),
                          ),
                          child: Text(
                            "Denda: Rp ${liveFine.toInt()}",
                            style: const TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                              fontSize: 11,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                _buildTrailingWidget(book, isMyBook, prov),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatusChip(String status) {
    Color color = status == 'Available' ? Colors.green : Colors.orange;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        status,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // --- FUNGSI TERPENTING: LOGIKA CEK DENDA ---
  Widget _buildTrailingWidget(
    BookModel book,
    bool isMyBook,
    LibraryProvider prov,
  ) {
    if (book.status == 'Available') {
      return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFD4AF37),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        onPressed: () => prov.requestBook(book.id),
        child: const Text(
          "Pinjam",
          style: TextStyle(color: Colors.white, fontSize: 11),
        ),
      );
    }

    if (isMyBook && book.status == 'Borrowed') {
      double fine = prov.calculateLiveFine(book.dueDate);

      return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: fine > 0 ? Colors.red : Colors.orange,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        onPressed: () {
          if (fine > 0) {
            // JIKA ADA DENDA -> Ke Halaman Bayar
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PaymentPage(book: book, fineAmount: fine),
              ),
            );
          } else {
            // JIKA TIDAK ADA DENDA -> Kembalikan Normal
            prov.returnBook(book.id);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Permintaan pengembalian terkirim")),
            );
          }
        },
        child: Text(
          fine > 0 ? "Bayar" : "Kembali",
          style: const TextStyle(color: Colors.white, fontSize: 11),
        ),
      );
    }

    if (isMyBook && book.status == 'Returning') {
      return const Icon(Icons.hourglass_top, color: Colors.blue);
    }
    return const Icon(Icons.lock_outline, color: Colors.grey, size: 22);
  }
}
