import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/library_provider.dart';
import '../../models/library_models.dart';

class PaymentPage extends StatefulWidget {
  final BookModel book;
  final double fineAmount;

  const PaymentPage({super.key, required this.book, required this.fineAmount});

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  String? _selectedMethod;

  final List<Map<String, dynamic>> _methods = [
    {'id': 'bank', 'name': 'Transfer Bank (VA)', 'icon': Icons.account_balance},
    {
      'id': 'ewallet',
      'name': 'E-Wallet (OVO/Dana/GoPay)',
      'icon': Icons.account_balance_wallet,
    },
    {'id': 'qris', 'name': 'QRIS', 'icon': Icons.qr_code_scanner},
  ];

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<LibraryProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Pembayaran Denda"),
        backgroundColor: Colors.redAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Detail Pembayaran",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 15),
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    widget.book.title,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  Text(
                    "Rp ${widget.fineAmount.toInt()}",
                    style: const TextStyle(
                      color: Colors.red,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              "Pilih Metode Pembayaran (Simulasi)",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            ..._methods.map(
              (method) => RadioListTile<String>(
                title: Text(method['name']),
                secondary: Icon(method['icon'], color: const Color(0xFF0000FF)),
                value: method['id'],
                groupValue: _selectedMethod,
                onChanged: (val) => setState(() => _selectedMethod = val),
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _selectedMethod == null
                      ? Colors.grey
                      : Colors.green,
                ),
                onPressed: _selectedMethod == null
                    ? null
                    : () {
                        // Simulasi bayar: memanggil fungsi konfirmasi di provider
                        prov.processReturnWithPayment(
                          widget.book.id,
                          widget.fineAmount,
                        );
                        _showSuccess(context);
                      },
                child: const Text(
                  "KONFIRMASI BAYAR",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSuccess(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.verified, color: Colors.green, size: 50),
        title: const Text("Pembayaran Berhasil"),
        content: const Text("Buku telah dikembalikan dan denda lunas."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Tutup dialog
              Navigator.pop(context); // Kembali ke Dashboard
            },
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }
}
