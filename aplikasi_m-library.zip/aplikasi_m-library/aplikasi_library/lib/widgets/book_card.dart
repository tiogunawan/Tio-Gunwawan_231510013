import 'package:flutter/material.dart';
import '../models/library_models.dart';
import '../shared/theme.dart';

class BookCard extends StatelessWidget {
  final BookModel book;
  final Widget trailingWidget;

  const BookCard({super.key, required this.book, required this.trailingWidget});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        contentPadding: const EdgeInsets.all(15),
        // Ikon buku menggunakan warna emas tema
        leading: const CircleAvatar(
          backgroundColor: AppColors.accentGold,
          child: Icon(Icons.book, color: Colors.white),
        ),
        title: Text(
          book.title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Text(
            "Penulis: ${book.author}\nStatus: ${book.status}",
            style: TextStyle(color: Colors.grey[700]),
          ),
        ),
        isThreeLine: true,
        trailing: SizedBox(
          width: 100, // Ukuran tombol di sebelah kanan
          child: trailingWidget,
        ),
      ),
    );
  }
}
